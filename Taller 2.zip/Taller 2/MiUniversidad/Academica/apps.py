from django.apps import AppConfig


class AcademicaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Academica'
